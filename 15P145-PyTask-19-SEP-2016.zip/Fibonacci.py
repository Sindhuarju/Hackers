li=[0,1]
num=input("enter the number:")
for i in range(1,int(num),1):
	li.append(li[i-1]+li[i])
print(li)

