bill=0
num=input("Enter the varieties of furniture to be purchased:")
if(int(num)>0):
	for i in range(0,int(num),1):
		print("1.sofaset 2.Dining table 3.T.V stand 4.Cupboard")
		a=int(input("enter the index of furniture:"))
		if(a==1):
			q=int(input("enter the quantity:"))
			bill+=q*20000
		elif(a==2):
			q=input("enter the quantity:")
			bill+=q*8500
		elif(a==3):
			q=input("enter the quantity:")
			bill+=q*4599
		elif(a==4):
			q=input("enter the quantity:")
			bill+=q*13920
	print(bill)
else:
	print("no furniture purchased")
