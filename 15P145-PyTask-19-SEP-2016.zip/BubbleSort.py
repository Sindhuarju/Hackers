li=[]
num=input("enter the number:")
for i in range(0,int(num),1):
	li.append(int(input()))
for j in range(0,int(num),1):
	for i in range(j+1,int(num),1):
		if(li[j]>li[i]):
			li[j]=li[i]+li[j]
			li[i]=li[j]-li[i]
			li[j]=li[j]-li[i]
print(li)